import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mean-stack',
  templateUrl: './mean-stack.component.html',
  styleUrls: ['./mean-stack.component.css']
})
export class MeanStackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
