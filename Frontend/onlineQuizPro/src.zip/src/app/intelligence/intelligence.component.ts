import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intelligence',
  templateUrl: './intelligence.component.html',
  styleUrls: ['./intelligence.component.css']
})
export class IntelligenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
